
// Archivo scripts.js con funciones de validacion en los formularios del sistema


/* funcion de validación de ingreso al sistema o login
Desarrollador: Juan Jose Murillo
Email: juanofilth@gmail.com
fecha: 8 julio 2025 */

function login() {
  // Datos simulados como si vinieran de una base de datos
  const usuarioGuardado = "admin";
  const contrasenaGuardada = "123adm";

  // Lo que escribe el usuario
  const usuarioIngresado = document.getElementById("usuario").value.trim();
  const contrasenaIngresada = document.getElementById("password").value.trim();

  // Validar campos vacíos
  if (usuarioIngresado === "" || contrasenaIngresada === "") {
    alert("Por favor completa todos los campos.");
    return;
  }

  // Verificar credenciales
  if (usuarioIngresado === usuarioGuardado && contrasenaIngresada === contrasenaGuardada) {
    window.location.href = "dashboard.html";
  } else if (usuarioIngresado !== usuarioGuardado && contrasenaIngresada === contrasenaGuardada) {
    alert("El usuario es incorrecto.");
  } else if (usuarioIngresado === usuarioGuardado && contrasenaIngresada !== contrasenaGuardada) {
    alert("La contraseña es incorrecta.");
  } else {
    alert("Usuario y contraseña incorrectos.");
  }
}


// funcion para menu hamburguesa
document.addEventListener("DOMContentLoaded", function () {
  // Obtener el botón y el menú
  const toggleButton = document.getElementById("toggleMenu");
  const nav = document.querySelector("nav");

  // Agregar evento al botón para mostrar u ocultar el menú
  toggleButton.addEventListener("click", function () {
    nav.classList.toggle("oculto");
  });
});

 // funcion para validaciones de formulario registrar libro
  function validarFormulario() {
    const titulo = document.getElementById('titulo').value.trim();
    const autor = document.getElementById('autor').value.trim();
    const genero = document.getElementById('genero').value.trim();
    const anio = document.getElementById('anio').value.trim();
    const portada = document.getElementById('portada').files[0];
    if (!titulo) {
      alert('El campo "Título" es obligatorio.');
      return false;
    }
    if (!autor) {
      alert('El campo "Autor" es obligatorio.');
      return false;
    }
    if (!genero) {
      alert('El campo "Género" es obligatorio.');
      return false;
    }
    if (!anio) {
      alert('El campo "Año" es obligatorio.');
      return false;
    }
    if (!portada) {
      alert('El campo portada es obligatorio.');
      return false;
    }

   alert("Formulario válido. Registrando datos...");
  
   
    return true;
  }
  
// sesión 29 julio 2025

 // Función que retorna un saludo según la hora local
    function obtenerSaludoSegunHora() {
      var fecha = new Date();
      var hora = fecha.getHours();
      var saludo = "";

      if (hora >= 6 && hora < 12) {
        saludo = "Buenos días!";
      } else if (hora >= 12 && hora < 18) {
        saludo = "Buenas tardes!";
      } else {
        saludo = "Buenas noches!";
      }

      return saludo;
    }

 document.addEventListener("DOMContentLoaded", function () {
  document.getElementById("saludo").textContent = obtenerSaludoSegunHora();
});
 


// Función que activa el buscador por título en la tabla
function activarBuscadorDeLibros() {
  var input = document.getElementById("buscador");

  if (!input) return; // Si no existe el input, salimos

  input.addEventListener("keyup", function () {
    var texto = input.value.toLowerCase();
    var filas = document.querySelectorAll("table tbody tr");

    filas.forEach(function (fila) {
      var titulo = fila.cells[1].textContent.toLowerCase();
      if (titulo.includes(texto)) {
        fila.style.display = "";
      } else {
        fila.style.display = "none";
      }
    });
  });
}

 
document.addEventListener("DOMContentLoaded", function () {
  activarBuscadorDeLibros();
});



